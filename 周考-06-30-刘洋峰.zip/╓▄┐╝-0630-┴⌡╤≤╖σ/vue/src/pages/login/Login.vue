<template>
  <div class="app">
    <div class="logins">
      <input
        v-model="inputValue"
        class="inpOne"
        type="text"
        placeholder="账户名"
        
      />
      <input
        v-model="inputValues"
        class="inpTow"
        type="password"
        placeholder="密码"
      />
      <button @click="toCapital">登录</button>
    </div>
  </div>
</template>

<script>
// import Capital from '../index/capital/Capital.vue'
import bus from '../index/capital/Capital.vue'

export default {
  data() {
    return {
      inputValue: "",
      inputValues: "",
      // user:inputValue
      // hasValue: false,
    };
  },
  // 计算属性
  Computed: {},
  // 侦听器
  watch: {
    
  },
  // 定义函数
  methods: {
    // login() {
    //     // 假设的登录方法
    //     this.doLogin().then(() => {
    //         isLoggedIn = true; // 更新登录状态
    //         // 获取从重定向路径传递过来的参数
    //         const redirectTo = this.$route.query.redirect;
    //         // 重定向到目的地路由或默认路由
    //         this.$router.push(redirectTo || '/');
    //     });
    // },
    toCapital() {
      if (this.inputValue === "") {
        window.alert("用户名不能为空");
      } else if (this.inputValue.trim() !== "admin") {
        window.alert("用户名不正确");
        this.inputValue = "";
      } else {
        if (this.inputValues === "") {
          window.alert("密码不能为空");
        } else if (this.inputValues.trim() !== "123") {
          window.alert("密码不正确");
          this.inputValues = "";
        } else {
          window.location.href = "http://10.37.15.72:8082/index/capital/CapitalForm";
        }
      }
    },
    // user(){
    //   this.$bus.$emit("user",'user')
    // }
  },
  // 注册组件
  components: {
    // Capital
    // bus
  },
};
</script>

<style lang="scss" scoped>
.app {
  width: 100vw;
  height: 100vh;
  background-color: #4b96e9;
  .logins {
    width: 400px;
    height: 400px;
    border-radius: 15px;
    padding: 100px 50px 100px;
    overflow: hidden;
    background-color: #fff;
    display: flex;
    flex-direction: column;
    position: absolute;
    top: 30%;
    left: 60%;
    .inpOne {
      width: 300px;
      height: 50px;
      outline: none;
      padding-left: 10px;
      border-radius: 5px;
      border: #dedede 1px solid;
    }
    .inpTow {
      width: 300px;
      height: 50px;
      margin: 30px 0;
      outline: none;
      padding-left: 10px;
      border-radius: 5px;
      border: #dedede 1px solid;
    }
    button {
      width: 300px;
      height: 50px;
      border: none;
      cursor: pointer;
      color: #fff;
      border-radius: 5px;
      background-color: #379bff;
    }
  }
}
</style>