<template>
  <div class="systemTow">
    <div class="main">
      <nav><h4>资金组成</h4></nav>
      <router-link to="/index/system" @click="User">用户管理</router-link>
    </div>

    <div class="info">
      <div class="head">
        <div class="navOne">{{'admin'}} | <span @click="del" style="cursor: pointer;">退出</span></div>
        <div class="navTow">
          <p v-for="(item,index) in list" :key="index">{{ item }}<img @click="dels" src="../../../assets/错号 (1).png" alt=""></p>

        </div>
      </div>
      <router-view class="infos" />
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: ['用户管理'],
    };
  },
  methods: {
    User() {

    },
    del() {
      window.location.href = "http://10.37.15.72:8082/login";
    },
    dels(index){
        this.list.splice(index,1)
        this.list.length === 0 ? window.location.href = "http://10.37.15.72:8082/login" : this.list
      },
  },
};
</script>

<style lang="scss" scoped>
.systemTow {
  width: 90vw;
  height: 100vh;
  display: flex;
  nav {
    padding: 40px;
    color: #fff;
    border-bottom: 3px solid #0570d4a6;
    h4 {
      text-align: center;
    }
  }
  .main {
    width: 15vw;
    // height: 100vh;
    display: flex;
    text-align: center;
    flex-direction: column;
    background-color: #031d49;
    a {
      color: #4e5d7d;
      padding: 30px;
    }
  }

  .info {
    width: 75vw;
    height: 100vh;
    .head {
      width: 75vw;
      height: 10vh;
      .navOne {
        height: 5vh;
        line-height: 5vh;
        text-align: end;
        padding-right: 20px;
        border-bottom: 1px solid #DDDDE1;

      }
      .navTow {
        height: 5vh;
        line-height: 5vh;
        text-align: start;
        padding-left: 20px;
        border-bottom: 1px solid #DDDDE1;

        p{
            width: 150px;
            display: flex;
            text-align: center;
            align-items: center;
            justify-content: center;
            border-right: 1px solid #DDDDE1;
            img{
              width: 16px;
              height: 16px;
            }
          }
      }
    }
  }
  .infos {
    flex: 1;
    background-color: #f0f2f6;
  }
}

.router-link-active {
  color: #fff !important;
  background: #395b94;
}
</style>