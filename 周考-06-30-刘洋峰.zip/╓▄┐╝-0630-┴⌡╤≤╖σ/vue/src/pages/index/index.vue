<template>
  <div class="Indexs">
        <nav>
            <router-link to="/index/capital">资金管理</router-link>
            <router-link to="/index/system">系统管理</router-link>
        </nav>
        <main>
            <router-view />
        </main>
  </div>
</template>

<script>
export default {
   
}
</script>

<style lang="scss" scoped>

    .Indexs{
        display: flex;
    }
    nav{
        width: 10vw;
        height: 100vh;
        padding-top: 100px;
        text-align: center;
        display: flex;
        flex-direction: column;
        background-color: #001236;
        a{
            color: #7182A8;
            padding: 25px;
        }
    }

    .router-link-active {
        color: #fff;
        background: #031D49;
    }
</style>