<template>
  <div class="infos">
    <!-- <nav></nav> -->
    <main>资金组成</main>  
    </div>
</template>

<script>
export default {

}
</script>

<style >
  .infos{
    height: 90vh;
    background-color: #F0F2F6;
  }
</style>