<template>
  <div class="capitalTow">
    <div class="main">
      <nav><h4>资金组成</h4></nav>
      <router-link to="/index/capital/CapitalForm" @click.native="Form">资金组成</router-link>
      <router-link to="/index/capital/CapitalFlow" @click.native = "Flow">资金流向</router-link>
      <router-link to="/index/capital/CapitalRoot" @click.native="Root">资金来源</router-link>
    </div>

      <div class="info">
        <div class="head">
            <div class="navOne">{{ "admin" }} | <span @click="del" style="cursor: pointer;">退出</span></div>
            <div class="navTow">
              <p :class="{active : item.flag}" v-for="(item,index) in list" :key="index">{{ item }}<img @click="dels" src="../../../assets/错号 (1).png" alt=""></p>
            </div>
        </div>
        <router-view  class="infos"/>
      </div>
  </div>

</template>

<script>


export default {
  // props: ['user'],
  data(){
        return{
            title:['资金组成','资金流向','资金来源'],
            list:['资金组成'],
            // flag:false
        }
    },
    methods: {
      Form(e){
        this.list.includes(this.title.slice(0,1)[0]) ? this.list : this.list.push(this.title.slice(1,2)[0])
        // this.list.map(i=>{return {...i,flag:true}})
      },
      Flow(){
        this.list.includes(this.title.slice(1,2)[0]) ? this.list : this.list.push(this.title.slice(1,2)[0])
        // this.list.map(i=>{return {...i,flag:true}})
        
      },
      Root(){
        this.list.includes(this.title.slice(2)[0]) ? this.list : this.list.push(this.title.slice(2)[0])
        // this.list.map(i=>{return {...i,flag:true}})

      },
      del(){
        window.location.href = "http://10.37.15.72:8082/login";

      },
      dels(index){
        this.list.splice(index,1)
        this.list.length === 0 ? window.location.href = "http://10.37.15.72:8082/login" : this.list
      }
      
    },
    // mounted(){
    //   this.$bus.$on("user",(params)=>{
    //     console.log(params)
    //   });
    // }
}
</script>

<style lang="scss" scoped>

  .capitalTow{
    width: 90vw;
    height: 100vh;
    display: flex;
    nav{
      padding: 40px;
      color: #fff;
      border-bottom: 3px solid #0570d4a6;
      h4{
        text-align: center;
      }
    }
    
    .main{
      width: 15vw;
      // height: 100vh;
      display: flex;
      text-align: center;
      flex-direction: column;
      background-color: #031D49;
      a{
        color: #4E5D7D;
        padding: 30px;
      }
    }
    .info{
      width: 75vw;
      height: 100vh;
      .head{
        width: 75vw;
        height: 10vh;
        .navOne{
          height: 5vh;
          line-height: 5vh;
          text-align: end;
          padding-right: 20px;
          border-bottom: 1px solid #DDDDE1;
        }
        .navTow{
          height: 5vh;
          line-height: 5vh;
          display: flex;
          text-align: start;
          padding-left: 20px;
          border-bottom: 1px solid #DDDDE1;
          p{
            width: 150px;
            border-right: 1px solid #DDDDE1;
            display: flex;
            text-align: center;
            align-items: center;
            justify-content: center;
            img{
              width: 16px;
              height: 16px;
            }
          }
        }
      }
    }
    .infos{
      flex: 1;
      background-color: #F0F2F6;

    }
  }
  .router-link-active {
    color: #fff !important;
    background: #395b94;
  }

  .active{
    background-color: orangered;
  }


</style>