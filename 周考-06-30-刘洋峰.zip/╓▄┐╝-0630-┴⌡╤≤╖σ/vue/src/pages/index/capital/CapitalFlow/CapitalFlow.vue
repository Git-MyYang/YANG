<template>
  <div>
    <nav></nav>
    <main>资金流向</main>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>