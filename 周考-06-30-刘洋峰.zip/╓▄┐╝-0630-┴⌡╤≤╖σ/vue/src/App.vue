<template>
  <div class="app">
    <router-view/>
  </div>
</template>


<script>
  export default {
  name: 'App',
  // data() {

  // },
  // 计算属性
  Computed:{
  },
   // 侦听器
   watch:{
  },
   // 定义函数
  methods:{

  },
   // 注册组件
  components: {
  }

}
  
</script>


<style lang="scss">
* {
  margin: 0;
  padding: 0;
  text-decoration: none;
  list-style: none;
  box-sizing: border-box;
}

</style>
