import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../pages/login/Login.vue'
import Index from '../pages/index/index.vue'
import System from '../pages/index/system/System.vue'
import SystemUser from '../pages/index/system/SystemUser/SystemUser.vue'
import Capital from '../pages/index/capital/Capital.vue'
// import CapitalDown from '../pages/index/capital/CapitalDown/CapitalDown.vue'
import CapitalForm from '../pages/index/capital/CapitalForm/CapitalForm.vue'
import CapitalFlow from '../pages/index/capital/CapitalFlow/CapitalFlow.vue'
import CapitalRoot from '../pages/index/capital/CapitalRoot/CapitalRoot.vue'
import Notfound from '../pages/404/404.vue'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: 'login',
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    // redirect: '/login',
    meta: { title: '登录' , requiresAuth: true },
  }, 
  {
    path: '/index',
    name: 'index',
    component: Index,
    meta: { title: '主页' },
    children: [
      {
        path: '/index/capital',
        name: 'capital',
        component: Capital,
        meta: { title: '资金管理' },
        redirect: '/index/capital/CapitalForm',
        children: [
          {
            path: '/index/capital/CapitalForm',
            name: 'CapitalForm',
            component: CapitalForm,
            meta: { title: '资金组成' },
          },
          {
            path: '/index/capital/CapitalFlow',
            name: 'CapitalFlow',
            component: CapitalFlow,
            meta: { title: '资金流向' },
          },
          {
            path: '/index/capital/CapitalRoot',
            name: 'CapitalRoot',
            component: CapitalRoot,
            meta: { title: '资金来源' },
          }
            // path: '/index/capital/CapitalDown',
            // name: 'CapitalDown',
            // component: CapitalDown,
            // meta: { title: '资金管理' },
            // children: [
              // {
            // ]
          // }
        ]
        
      },
      {
        path: '/index/system',
        name: 'system',
        component: System,
        meta: { title: '系统管理' },
        redirect: '/index/system/SystemUser',
        children: [
          {
            path: '/index/system/SystemUser',
            name: 'SystemUser',
            component: SystemUser,
            meta: { title: '用户管理' },
          }
        ]
      },
    ]
  },

 
  {
    path:'*',
    name:'404',
    component: Notfound
}

]


// // 全局前置守卫
// router.beforeEach((to, from, next) => {
//   const isLoggedIn = false;

//   if (to.matched.some(record => record.meta.requiresAuth) && !isLoggedIn) {
//     // 如果用户访问需要登录的页面但未登录，则重定向到登录页面
//     next({
//       path: '/login',
//       query: { redirect: to.fullPath } // 将目的地路由传递给登录页面
//     });
//   } else {
//     // 如果用户已登录或访问的是公开页面，允许导航
//     next();
//   }
// });

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
