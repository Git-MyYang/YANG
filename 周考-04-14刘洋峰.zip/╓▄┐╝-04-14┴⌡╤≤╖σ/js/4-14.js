// 第一题：二维数组的对角线求和（20分）
// 问题描述： 编写一个函数 diagonalSum，该函数接收一个二维数组（矩阵）作为参数，并返回其主对角线元素的和。主对角线是从矩阵的左上角到右下角的对角线。
// 1.函数应返回一个数字，表示所有在主对角线上的元素的和。
// 2.确保二维数组至少为 1x1 大小，并且是方阵（即行和列数相等）。
// 3.处理任何大小的方阵。




// // 声明一个变量
// var matrix = [[1, 2, 3],[4, 5, 6],[7, 8, 9]]; 
// // 封装一个函数
// function diagonalSum(str) {
// console.log(str)
// var newArr = 0
// // 循环遍历 拿到数组
// for(var i = 0; i < str.length; i++){
//     for(var j = 0 ; j <= i; j++){
//         return newArr = str[i][j] + str[i+1][j+1] + str[i+2][j+2]
//     }
    
// }
// }
// console.log(diagonalSum(matrix));
// // // 应输出：15 (即 1 + 5 + 9)






// 第二题：旋转数组（20分）
// 问题描述： 编写一个函数 rotateArray，该函数接收一个数组和一个整数 k 作为参数。函数的任务是将数组中的元素向右移动 k 个位置，其中 k 是非负数。



// // 封装函数
// function rotateArray(array, num) {
// // // 实现逻辑
// // 循环遍历
// // 创建新数组
// var newArr = []
// // 截取下表和删除项
//     newArr = array.splice(array.length - num , num)
//     // 合并输出
//     return newArr.concat(array)
// }
// var arr = [1, 2, 3, 4, 5, 6, 7];
// console.log(rotateArray(arr, 3));
// // // 应输出：[5, 6, 7, 1, 2, 3, 4]







// 第三题：最长公共前缀（20分）
// 问题描述：
// 编写一个函数 longestCommonPrefix，该函数接收一个字符串数组，并返回数组中所有字符串的最长公共前缀。如果不存在公共前缀，则返回一个空字符串。
// 要求：
// 函数应返回字符串数组中所有元素的最长公共前缀。
// 如果数组为空，返回空字符串。
// 如果没有公共前缀，则返回空字符串。

// // 声明输入变量
// var words = ["flower", "flow", "flight"];
// var words2 = ["dog", "racecar", "car"];
// // 封装函数
// function longestCommonPrefix(arr){
//     var newArr = []
//     // 循环遍历
//     for(var i = 0; i < arr.length; i++){
//         var newArr1 = arr[i].split("")
//         console.log(newArr1)
//         for(var j = 0; j <= arr[i].length; j++){
//             // 判断拿到所有元素的最长公共前缀
//             if(arr[0].indexOf(arr[0][j])===arr[arr.length-i].indexOf(arr[arr.length-i][j])===arr[arr.length - i - 1].indexOf(arr[arr.length - i - 1][j])){
//                 newArr.push(arr[i][j])
//                 // 如果没有返回空字符串
//             }else{
//                 newArr = ""
//             }
//         }
//     }
//     return newArr
// }
// console.log(longestCommonPrefix(words));
// // 应输出："fl"
// console.log(longestCommonPrefix(words2));
// // 应输出：""









// 第四题：子串出现次数（20分）
// 问题描述：
// 编写一个函数 countSubstrings，该函数接收两个字符串参数：str（原始字符串）和 sub（子字符串）。函数的任务是计算子字符串在原始字符串中出现的次数。


// // 封装函数
// function countSubstrings(str,sub){
//     // 声明变量0进行累加
//     var Str = 0
//     // 去除字符串空格
//     str = str.split(" ").join("")
//     sub = sub.split("")
//     // 循环遍历
//     for(var i = 0; i < str.length; i++){
//         // 判断截取长度和子字符串是否相等
//         if(sub.join("") === str.substr(i,sub.length)){
            
//         //   str = (sub.join("")).concat(str)
//           Str++
//         // console.log(str)
//         }
        
//     }
//     return Str
// }
// console.log(countSubstrings("hello hello world", "hello"));
// // // 应输出：2
// console.log(countSubstrings("abcabcabc", "abc"));
// // // 应输出：3





// 第五题：格式化货币金额（20分）
// 问题描述：
// 编写一个函数 formatMoney，该函数接收一个数字作为参数，并将其格式化为带有千位分隔符的金额格式。该函数应确保所有输出的金额格式均包含两位小数，并使用逗号作为千位分隔符。
// 要求：
// 1.函数必须处理任意大小的正数、负数或零，并正确格式化为带有两位小数的字符串。
// 2.输出的字符串应包含适当的千位分隔符。
// 3.函数应兼容整数和浮点数，确保浮点数始终显示两位小数，即使这两位是零。
// 4.如果数值为负数，负号应出现在最前面。




// function formatMoney(arr){
//     // 判断正负数
//     arr < 0 ? "-" + arr : arr
    
//      ((arr - parseInt(arr)) /10)
    

    
// }
// console.log(formatMoney(1234567.891));
// // 应输出："1,234,567.89"
// console.log(formatMoney(1000));
// // 应输出："1,000.00"
// console.log(formatMoney(199.99));
// // 应输出："199.99"
// console.log(formatMoney(-5310.25));
// // 应输出："-5,310.25"



