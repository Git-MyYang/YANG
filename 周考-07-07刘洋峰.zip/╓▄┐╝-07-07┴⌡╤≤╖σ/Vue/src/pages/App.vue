<script setup>
import {RouterView}  from 'vue-router'
</script>

<template>

    <div>
      <RouterView />
    </div>

</template>

<style>
*{
  padding: 0;
  margin: 0;
  text-decoration: none;
  list-style: none;
  box-sizing: border-box;
}
html{
  width: 100%;
  height: 100%;
}
body{
  width: 100%;
  height: 100%;
  /* background-color: aqua; */
}

</style>

