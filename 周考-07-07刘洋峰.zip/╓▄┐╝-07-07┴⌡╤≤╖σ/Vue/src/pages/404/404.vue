<template>
    <div>
      <h2>页面不存在</h2>
      <router-link to="/home">去首页</router-link>
    </div>
  </template>
  
  <script>
  export default {
  
  }
  </script>
  
  <style>
  
  </style>