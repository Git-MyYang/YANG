<template>
    <div class="app">
        <div class="lefts"  v-for="(item,index) in arr" :key="index">
            <img src="" alt="">
            <div>{{ item.src }}</div>
            <div>{{ item.title }}</div>
            <div>{{ item.year }}</div>
            <div>{{ item.region }}</div>
            <div>{{ item.alcohol }}</div>
            <div>{{ item.price }}</div>
            <button>Add to cart</button>
        </div>
        <div class="intos">
            <img src="" alt="">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <button>Add to cart</button>
        </div>
        <div class="rights">
            <img src="" alt="">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <button>Add to cart</button>
        </div>
    </div>
</template>

<script>

export default {
    props:["arr"],
  name: 'App',
   
    // 计算属性
    Computed:{
    },
    // 侦听器
    watch:{
    },
    // 定义函数
    methods:{
      
    },
    // 注册组件
    components: {
    }
}
</script>

<style lang="scss">
    *{
        padding: 0;
        margin: 0;
        list-style: none;
        text-decoration: none;
        box-sizing: border-box;
    }
</style>
