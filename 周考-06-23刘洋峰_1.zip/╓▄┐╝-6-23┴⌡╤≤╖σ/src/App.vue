<template>
    <div class="app">
        <!-- <index
        :data="data"

        ></index> -->
        <div class="infoBOX">
            <higBor :count="count"
            :arr="arr"
            
            ></higBor>

            <main>
                <dl v-for="(item,index) in data" :key="index" :class="{borders : item.flag}">
                    <dt><img :src= item.src alt=""></dt>
                    <dd>
                        <img class="adds" @click="borFn($event,index)" src="./assets/加号.png" alt="">
                        <h3>{{ item.title }}</h3>
                        <div>{{ item.price }}</div>
                        <button @click="borFn($event,index)">Add to cart</button>
                    </dd>
                </dl>
            </main>
        </div>
    </div>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue'
import higBor from './higBor.vue'
import index from './index.vue'
import axios from 'axios';


export default {
  name: 'App',
    data() {
        return {
           data: null,
           error: null,
           count:0,
           flag:false,
           arr:[]
        }
    },
    // 计算属性
    Computed:{
    },
    // 侦听器
    watch:{
    },
    // 创建钩子
    created() {
        this.fetchData();
  },
    // 定义函数
    methods:{
        fetchData(){
            axios.get("https://zyxcl.xyz/exam_api/bottle")
            .then(response => {
                this.data = response.data.value.map(i=>{return {...i,flag:false}});
                console.log(this.data)
            })
            .catch(error => {
                this.error = error.message;
            });
        },
        borFn(event,index){
            this.arr.length <=3 ? event.target.parentNode.parentNode.classList.add("borders") : this.arr.length === 3
            this.count++
            // console.log(this.count,event.target.parentNode.parentNode)
            // const e = event.target.parentNode.lastElementChild
            // console.log(this.arr,e.innerHTML,item.title) 
            // this.data.flag = !this.data.flag
            // console.log(index)
            this.arr.push(this.data[index])
            this.arr.length > 3 ? this.arr.length = 3 : this.arr.length = this.arr.length
            console.log(this.arr)
        }
        
    
    },
    // 注册组件
    components: {
        higBor,
        index
    }
}
</script>

<style lang="scss">
    *{
    padding: 0;
    margin: 0;
    list-style: none;
    text-decoration: none;
    box-sizing: border-box;
}
html,body{
    height: 100%;
    width: 100%;
}

main{

    background-color: #292B2F;
    display: flex;
    padding: 0 50px;
    padding-left: 200px;
    flex-wrap: wrap;
    color: #ffffff;
}
main dl{
    background-color: #232529;
    padding: 20px;
    width: 20%;
    margin: 20px;
    text-align: center;
    position: relative;
}
main dl dd >div{
    margin: 20px 0;
    color: #6E70BB;
}
main dl dd button{
    padding: 10px 30px;
    color: #ffffff;
    background-color: #2C2D34;
}
.adds{
    position: absolute;
    width: 30px;
    top: 5%;
    left: 85%;
    background-color: #ffffff;
}
.borders{
    border: 3px solid #4047C3;
    border-radius: 5px;
}
</style>
