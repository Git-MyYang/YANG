<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
 

  <RouterView />
</template>

<style scoped>
*{
  padding: 0;
  margin: 0;
  text-decoration: none;
  list-style: none;
}

</style>
