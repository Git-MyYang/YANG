// 最后一天

function getDay(year,month,getLastDay){
    if(getLastDay){
        var date = new Date(year,month-1,Month(year,month))
        week = date.getDay()
        return year + "年" + month + "最后一天" + Week(week)

    }else{
        var date = new Date(year,month-1,1)
        week = date.getDay()
        return year + "年" + month + "第一天" + Week(week)
    }
}


// 判断月
function Month(year,month){
    var year ;
    switch(month){
        case 1:

        case 3:

        case 5:

        case 7:

        case 8:

        case 10:

        case 12:
            return 31

        case 2:
            return ( year % 4 === 0 && year % 100 != 0 || year % 400 ===0 ) ? 29 : 28

        case 4:

        case 6:

        case 9:

        case 11:
            return 30
    }

}

function Week(week){
    switch(week){
        case 0:
            return "星期日"

        case 1:
            return "星期一"

        case 2:
            return "星期二"

        case 3:
            return "星期三"

        case 4:
            return "星期四"

        case 5:
            return "星期五"

        case 6:
            return "星期六"
    }
}

console.log(getDay(2023,12,false))
console.log(getDay(2023,12,true))