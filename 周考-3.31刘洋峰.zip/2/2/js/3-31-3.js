for(var i = 1 ; i <= 9 ; i++){
    
    for(var m = 1 ; m <= i ; m++){
        var str = m + "*" + i;
        // if(
        //     i
        // )

document.write(str)
    }
document.write("<br>")

}
document.write("<br>")
document.write("<br>")
document.write("<br>")



for(var n = 1 ; n <= 9 ; n++){

    for(var t = 9 ; t >= n ; t--){
        var num = t + "*" + n

        document.write(num)
    }
    document.write("<br>")
}


