var num1 = +prompt("请输入年份");
var num2 = +prompt("请输入月份");
// for(num1 = 1990 ; num1 <= 2020; num1++){
//     function fn(str){

//        alert("")
//     }
    // fn(num1)
    if(typeof(num1) === "number" && num1 >= 1990 && num1 <= 2020){
        
        if(typeof(num2)=== "number" && num2 >=1 && num2 <= 12){
          alert("成功输入")
          document.write(fn())
        }else{
            alert("错误请重新输入")
            
        }
    }else{
        alert("错误请重新输入")
    }


function fn(){
for(var num1 = 1990 ; num1 <=2020 ; num1++){
    
    console.log(num1)
        for(var num2 = 1 ; num2 <= 12 ; num2++){
            if(num2 = 2){
                if(num1 % 4 === 0 && num1 / 100 != 0 || num1 / 400 === 0){
                    document.write(num1 + "2月共28天")
                }else{
                    document.write(num1 + "2月共29天")
                }
                
            }else if(num2 = 4 , num2 <= 12 , num2 += 2){
                document.write(num1 + "" + num2 + "月共30天")
            }else{
                document.write(num1 + "" + num2 + "月共31天")

            }
        }
        
}
}
fn()